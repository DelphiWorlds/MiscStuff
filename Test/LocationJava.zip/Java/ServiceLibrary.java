package com.delphiworlds.LocationDemo;

import android.location.Location;

public class ServiceLibrary {
  static { System.loadLibrary("Service");  }
  static public native int Test(int value);
  static public native void ReceivedLocationString(String json);
  static public native void ReceivedLocation(Location location);
}