Test case for integration of Twain with Remote Desktop Services

Notes:

Apologies for the fairly messy code - the test cases have been "thrown together" just to demo the issues. 

The code for the RDS parts came from an article on the web that I'm unable to find at the moment.
Oddly enough, it was built for sending scanned files from the local machine to the RDS client, however did not use Twain

The units related to the article are:

  RDP.pas  
  RdpPacketsU.pas
  TestClient\AurRdpPluginU.pas
  TestDLL\VirtualChannel.pas  (a number of parts have been commented out as they are unused)

Twain related units:

  TestDLL\SimpleExampleForm.pas  (modified somewhat to allow selection of a source)
  TestDLL\Twain.pas (unaltered, I think)
  TestDLL\WSDelphiTwain.pas   (originally DelphiTwain.pas, with some of our own modifications)

The unit:

  TestDLL\WSDLLSynchnorizer.pas

was built in order to be able to use Synchronize from a DLL (it would otherwise not work), since the virtual channel code uses threads to receive data


The projects in the TestClient and TestDLL folder are dual purpose. When run on the local machine, the RDSTestClient can (with the correct path) load the RDSTest DLL (using the Scan via DLL button) and call the exported StartScan method. This is to verify that if the DLL is loaded "normally" all works as expected.

When run on the remote machine, using the Scan via RDS button in RDSTestClient opens a virtual channel with RDSTest DLL (if RDS is configured to use it), and the DLL presents the user with the TDelphiTwain simple example form. In this mode, clicking Acquire will either crash the DLL, or acquire a distorted image, or both.

Please notify me if there's anything missing.

Dave Nottage (davidn@radsoft.com.au)


