Multicast issues test case  (tested with Delphi 10.3.2)

The issue:

Multicast packets are not being received on Posix OS's (Tested: macOS (64-bit), iOS and Android)

To reproduce the issue:

1. Compile and run without debugging for Windows
2. Compile and run for a Posix OS such as Android
3. In the Windows executable, click Start Sender
4. In the Android executable, click Start Receiver
Expected: Packets are received on Android
Actual: No packets are received
5. Click Stop Receiver and Start Sender on Android
7. Click Stop Sender and Start Receiver on Windows
Packets are received on Windows


Test case notes:

IdStackVCLPosix.pas is a modified version of the unit supplied with 10.3.2, to allow access to the interface indexes, which is used in the TIdSocketHandleHelper.EnableMulticastInterface method in MC.IPMCastServer.pas 

TIPMCastServer in MC.IPMCastServer.pas is a reworked version of TIdIPMCastServer to allow bindings to individual addresses

TIPMCastClient in MC.IPMCastClient.pas is a reworked version of TIdIPMCastClient to allow individual bindings to fail without causing the whole client to fail.
