unit Unit1;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs, FMX.Controls.Presentation, FMX.StdCtrls;

type
  TForm1 = class(TForm)
    InfoLabel: TLabel;
    Button1: TButton;
    procedure Button1Click(Sender: TObject);
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  Form1: TForm1;

implementation

{$R *.fmx}

uses
  Macapi.ObjectiveC,
  iOSapi.Foundation,
  Posix.Dlfcn;

const
  libGameController = '/System/Library/Frameworks/GameController.framework/GameController';

type
  // Partial import of GC classes
  GCController = interface;
  GCMouse = interface;

  GCControllerClass = interface(NSObjectClass)
    ['{73C7A4EC-69C7-47DA-8EAE-8F35EB81ED8E}']
    {class} function controllers: NSArray; cdecl;
    {class} function current: GCController; cdecl;
  end;

  GCController = interface(NSObject)
    ['{16BC6BD0-42CC-418A-9507-E0CE84A8DA36}']
  end;
  TGCController = class(TOCGenericImport<GCControllerClass, GCController>) end;

  GCMouseClass = interface(NSObjectClass)
    ['{3A4B7D5B-70FD-47DD-9D96-596CA01A9953}']
    {class} function current: GCMouse; cdecl;
    {class} function mice: NSArray; cdecl;
  end;

  GCMouse = interface(NSObject)
    ['{A53F8ADF-DF9B-4705-9A68-A93CB947B3CD}']
  end;
  TGCMouse = class(TOCGenericImport<GCMouseClass, GCMouse>) end;

var
  GameControllerModule: THandle;

{ TForm1 }

constructor TForm1.Create(AOwner: TComponent);
begin
  inherited;
  //
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  InfoLabel.Text := Format('Mice count: %d, Controllers count: %d', [TGCMouse.OCClass.mice.count, TGCController.OCClass.controllers.count]);
end;

initialization
  GameControllerModule := dlopen(MarshaledAString(libGameController), RTLD_LAZY);

finalization
  dlclose(GameControllerModule);

end.
