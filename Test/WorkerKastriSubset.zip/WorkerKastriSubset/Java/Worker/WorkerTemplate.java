package com.delphiworlds.kastri;

/*******************************************************
 *                                                     *
 *                     Kastri                          *
 *                                                     *
 *        Delphi Worlds Cross-Platform Library         *
 *                                                     *
 *   Copyright 2020 Dave Nottage under MIT license     *
 * which is located in the root folder of this library *
 *                                                     *
 *******************************************************/

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull; 
import androidx.work.Data;
import androidx.work.ListenableWorker.Result;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class <%WorkerName%> extends Worker {

  private static final String TAG = "<%WorkerName%>";
  private ResolvableFuture<Payload> mFuture;

  public <%WorkerName%>(@NonNull Context context, @NonNull WorkerParameters workerParams) {
    super(context, workerParams);
    mFuture = ResolvableFuture.create();
    DWProxyWorker.workerCreate("lib<%WorkerName%>.so");
  }

  @Override
  public Result doWork() {
    return DWProxyWorker.doWork(this, "lib<%WorkerName%>.so");
  }

/*  "Future" enhancement ;-)
 // https://www.youtube.com/watch?v=83a4rYXsDs0  12:44
  @Override
  public ListenableFuture<ListenableWorker.Result> startWork() {
    if (!DWProxyWorker.startWork(this))
      mFuture.set(new Payload(Result.FAILURE, Data.EMPTY));
    return mFuture;
  }
*/

}


