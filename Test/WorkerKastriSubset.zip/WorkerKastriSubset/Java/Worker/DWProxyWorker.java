package com.delphiworlds.kastri;

/*******************************************************
 *                                                     *
 *                     Kastri                          *
 *                                                     *
 *        Delphi Worlds Cross-Platform Library         *
 *                                                     *
 *   Copyright 2020 Dave Nottage under MIT license     *
 * which is located in the root folder of this library *
 *                                                     *
 *******************************************************/

import android.content.Context;
import android.util.Log;
import androidx.work.Worker;
import androidx.work.ListenableWorker.Result;

public class DWProxyWorker {

  private static final String TAG = "DWProxyWorker";

  static {
    System.loadLibrary("DWProxyWorker");
  }

  static private native void workerCreateNative(Context context, String libName);
  static private native Result doWorkNative(Worker worker, String libName);
  static private native boolean startWorkNative(Worker worker, String libName);

  static public void workerCreate(Context context, String libName) {
    workerCreateNative(context, libName);
  }

  static public Result doWork(Worker worker, String libName) {
    return doWorkNative(worker, libName);
  }

  static public boolean startWork(Worker worker, String libName) {
    return startWorkNative(worker, libName);
  }     
}
