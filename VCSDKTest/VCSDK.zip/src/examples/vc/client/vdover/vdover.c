/*************************************************************************
*
*  Copyright (C) Citrix Systems, Inc. All Rights Reserved.
*
* VDOVER.C
*
* Virtual Driver Example - Over
*
* $Id: 
*
* The code and comments contained in this file are provided "as is"
* without warranty of any kind, either expressed or implied,
* including, but not limited to, the implied warranties of
* merchantability and/or fitness for a particular purpose.
* You have the right to use, modify, reproduce, and distribute
* this file, and/or any modified version of this file, in any way
* that you find useful, provided that you agree that Citrix Systems
* has no warranty obligations or liability for this or any other
* sample file.
*
* REMARKS:
*	This sample program will work with all clients.  It has been enhanced
*	to send data immediately when working with the HPC client (Version >= 13.0).
*	
*   This sample program illustrates the simplest way to make an existing
*   driver "HPC aware."
*	
*	When the HPC client is detected, this driver works without regular polling.
*	When ICA data arrives from the server, the driver requests an immediate poll.
*	The HPC engine will immediately call the DriverPoll function, and the driver
*	will then send the data to the server.
*
*************************************************************************/

#ifdef DOS32
#define CITRIX 1
#include <sys/types.h>
#include "wfc32.h"
#endif

#ifndef unix
#include <windows.h>         /* for far etc. */
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "citrix.h"
#include "clib.h"

/* from src/shared/inc/citrix */
#include "ica.h"
#include "ica-c2h.h"
#include "vdover.h"

/* from src/inc */
#include "icaconst.h"
#include "clterr.h"
#include "wdapi.h"
#include "vdapi.h"
#include "vd.h"
#include "ctxdebug.h"
#include "logapi.h"
#include "miapi.h"

//=============================================================================
//==   Definitions
//=============================================================================

#ifdef DEBUG
#pragma optimize ("", off)	// turn off optimization
#endif // DEBUG

#define SIZEOF_CONSOLIDATION_BUFFER 2000		// size of the consolidation buffer to allocate (arbitrary 2000 for the sample).
#define NUMBER_OF_MEMORY_SECTIONS 1             // number of memory buffers to send as a single packet

//=============================================================================
//==   Functions Defined
//=============================================================================
 
// These are the required driver functions (exported)

int DriverOpen(PVD, PVDOPEN, PUINT16);
int DriverClose(PVD, PDLLCLOSE, PUINT16);
int DriverInfo(PVD, PDLLINFO, PUINT16);
int DriverPoll(PVD, PVOID, PUINT16);
int DriverQueryInformation(PVD, PVDQUERYINFORMATION, PUINT16);
int DriverSetInformation(PVD, PVDSETINFORMATION, PUINT16);
int DriverGetLastError(PVD, PVDLASTERROR);

static void WFCAPI ICADataArrival(PVOID, USHORT, LPBYTE, USHORT);

//=============================================================================
//==   Data
//=============================================================================

PVOID g_pWd = NULL;                           // returned when we register our hook
PQUEUEVIRTUALWRITEPROC g_pQueueVirtualWrite  = NULL;  // returned when we register our hook
BOOL g_fBufferEmpty = TRUE;					// True if the data buffer is empty
PDRVRESP g_pDrvToSrv = NULL;                // pointer to reply buffer from drv to Srv
POVER g_pOver = NULL;                       // Pointer to receive data from Srv
BOOL g_fIsHpc = FALSE;					    // T: The engine is HPC
PSENDDATAPROC g_pSendData = NULL;		    // pointer to the HPC engine SendData function
LPBYTE g_pbaConsolidationBuffer = NULL;	    // buffer to consolidate a write that spans the end and beginning of the ring buffer.
USHORT g_usMaxDataSize = 0;                 // Maximum Data Write Size
USHORT g_usVirtualChannelNum = 0;           // Channel number assigned by WD
MEMORY_SECTION g_MemorySections[NUMBER_OF_MEMORY_SECTIONS];  // memory buffer pointer array
ULONG g_ulUserData = 0xCAACCAAC;      		// sample user data for HPC

/*******************************************************************************
 *
 *  DriverOpen
 *
 *    Called once to set up things.
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *    pVdOpen (input/output)
 *       pointer to the structure VDOPEN
 *    puiSize (Output)
 *       size of VDOPEN structure.
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - no error
 *    CLIENT_ERROR_NO_MEMORY - could not allocate data buffer
 *    On other errors, an error code is returned from lower level functions.
 *
 ******************************************************************************/

int DriverOpen(PVD pVd, PVDOPEN pVdOpen, PUINT16 puiSize)
{
    WDSETINFORMATION   wdsi;
    VDWRITEHOOK        vdwh;
	VDWRITEHOOKEX      vdwhex;					// struct for getting more engine information, used by HPC
    WDQUERYINFORMATION wdqi;
    OPENVIRTUALCHANNEL OpenVirtualChannel;
    int                rc;
    UINT16             uiSize;

    TRACE((TC_VD, TT_API1, "VDOVER: DriverOpen entered"));

    g_fBufferEmpty = TRUE;

    *puiSize = sizeof(VDOPEN);

    // Get a virtual channel

    wdqi.WdInformationClass = WdOpenVirtualChannel;
    wdqi.pWdInformation = &OpenVirtualChannel;
    wdqi.WdInformationLength = sizeof(OPENVIRTUALCHANNEL);
    OpenVirtualChannel.pVCName = CTXOVER_VIRTUAL_CHANNEL_NAME;

    // uiSize will be set  when we return back from VdCallWd.

    uiSize = sizeof(WDQUERYINFORMATION);

    rc = VdCallWd(pVd, WDxQUERYINFORMATION, &wdqi, &uiSize);
    TRACE((TC_VD, TT_API1, "VDOVER: opening channel %s", OpenVirtualChannel.pVCName));

    if(CLIENT_STATUS_SUCCESS != rc)
    {
        TRACE((TC_VD, TT_ERROR, "VDOVER: Could not open %s. rc=%d.", OpenVirtualChannel.pVCName, rc));
        return(rc);
    }

    g_usVirtualChannelNum = OpenVirtualChannel.Channel;

    pVd->pPrivate   = NULL; /* pointer to private data, if needed */

    // Register write hooks for our virtual channel

    vdwh.Type  = g_usVirtualChannelNum;
    vdwh.pVdData = pVd;
    vdwh.pProc = (PVDWRITEPROCEDURE) ICADataArrival;
    wdsi.WdInformationClass  = WdVirtualWriteHook;
    wdsi.pWdInformation      = &vdwh;
    wdsi.WdInformationLength = sizeof(VDWRITEHOOK);
    uiSize                   = sizeof(WDSETINFORMATION);

    rc = VdCallWd(pVd, WDxSETINFORMATION, &wdsi, &uiSize);
    TRACE((TC_VD, TT_API2, "VDOVER: writehook channel number=%u, vdwh.pVdData=%x rc=%d", vdwh.Type, vdwh.pVdData, rc));

    if(CLIENT_STATUS_SUCCESS != rc)
    {
        TRACE((TC_VD, TT_ERROR, "VDOVER: Could not register write hook. rc %d", rc));
        return(rc);
    }
    g_pWd = vdwh.pWdData;										// get the pointer to the WD data
    g_pQueueVirtualWrite = vdwh.pQueueVirtualWriteProc;			// grab pointer to function to use to send data to the host

    // Do extra initialization to determine if we are talking to an HPC client

    wdsi.WdInformationClass = WdVirtualWriteHookEx;
    wdsi.pWdInformation = &vdwhex;
    wdsi.WdInformationLength = sizeof(VDWRITEHOOKEX);
    vdwhex.usVersion = HPC_VD_API_VERSION_V1;					// Set version to 0; older clients will do nothing
    rc = VdCallWd(pVd, WDxQUERYINFORMATION, &wdsi, &uiSize);
    TRACE((TC_CDM, TT_API2, "VDOVER: WriteHookEx Version=%u p=%lx rc=%d", vdwhex.usVersion, vdwhex.pSendDataProc, rc));
    if(CLIENT_STATUS_SUCCESS != rc)
    {
        TRACE((TC_CDM, TT_API1, "VDOVER: WD WriteHookEx failed. rc %d", rc));
        return(rc);
    }
    g_fIsHpc = (HPC_VD_API_VERSION_LEGACY != vdwhex.usVersion);	// if version returned, this is HPC or later
    g_pSendData = vdwhex.pSendDataProc;         // save HPC SendData API address
   
    // If it is an HPC client, tell it the highest version of the HPC API we support.

    if(g_fIsHpc)
    {
       WDSET_HPC_PROPERITES hpcProperties;

       hpcProperties.usVersion = HPC_VD_API_VERSION_V1;
       hpcProperties.pWdData = g_pWd;
       hpcProperties.ulVdOptions = HPC_VD_OPTIONS_NO_POLLING;
       wdsi.WdInformationClass = WdHpcProperties;
       wdsi.pWdInformation = &hpcProperties;
       wdsi.WdInformationLength = sizeof(WDSET_HPC_PROPERITES);
       TRACE((TC_CDM, TT_API2, "VDOVER: WdSet_HPC_Properties Version=%u ulVdOptions=%lx g_pWd=%lx.", hpcProperties.usVersion, hpcProperties.ulVdOptions, hpcProperties.pWdData));
       rc = VdCallWd(pVd, WDxSETINFORMATION, &wdsi, &uiSize);
       if(CLIENT_STATUS_SUCCESS != rc)
       {
           TRACE((TC_CDM, TT_API1, "VDOVER: WdSet_HPC_Properties failed. rc %d", rc));
           return(rc);
       }
    }

    TRACE((TC_VD, TT_API1, "VDOVER: Registered"));

    // ALL MEMORY MUST BE ALLOCATED DURING INITIALIZATION.
    // Allocate a single buffer to send commands to the server
    // This example shows use of the MaximumWriteSize returned via
    // the previous call.
    // Subtract one because the first byte is used internally by the
    // WD for the channel number.  We are given a pointer to the
    // second byte.

    if(NULL == (g_pDrvToSrv = (PDRVRESP)malloc(sizeof(DRVRESP))))
    {
        return(CLIENT_ERROR_NO_MEMORY);
    }

    memset(g_pDrvToSrv, 0, sizeof(DRVRESP));

    // g_pOver is used as the buffer to receive the data from the server.

    if(NULL == (g_pOver = (POVER)malloc(sizeof(OVER))))
    {
        return(CLIENT_ERROR_NO_MEMORY);
    }
    return(CLIENT_STATUS_SUCCESS);
}

/*******************************************************************************
 *
 *  ICADataArrival
 *
 *   A data PDU arrived over our channel.
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *
 *    uChan (input)
 *       ICA channel the data is for.
 *
 *    pBuf (input)
 *       Buffer with arriving data packet
 *
 *    Length (input)
 *       Length of the data packet
 *
 * EXIT:
 *       void
 *
 ******************************************************************************/

static void WFCAPI ICADataArrival(PVOID pVd, USHORT uChan, LPBYTE pBuf, USHORT Length)
{
    // ICADataArrival is called (polled) when the underlying WinStation 
    // Driver(WD) has data to pass to the Virtual Channel.This g_fBufferEmpty 
    // condition is added so that the client does not accept any more data till
    // it has send back a message to the server.The data send by the server 
    // during this time will be lost. If the following condition is not checked 
    // then the client can continue to receive data from the server.(The data 
    // being stored by the WD.)  
     
    if(!g_fBufferEmpty)
    {
        TRACE((TC_VD, TT_ERROR, "VDOVER: ICADataArrival - Error: not all data was sent"));
        return;
    }

    TRACE((TC_VD, TT_API3, "VDOVER: IcaDataArrival, Len=%d, uLen=%d, ulServerMS=%d", Length, ((POVER)pBuf)->uLen, ((POVER)pBuf)->ulServerMS));
    TRACEBUF((TC_VD, TT_API3, pBuf, 20));

    if(((POVER)pBuf)->uLen > g_usMaxDataSize)
    {
        g_pOver->uLen = g_usMaxDataSize;
    }
    else {
        g_pOver->uLen = ((POVER)pBuf)->uLen;
    }

    // Copy data from pBuf - buffer with arriving data packet to
    // g_pOver - buffer to hold the packet type being sent by the
    // server.

    //memcpy(g_pOver, pBuf, sizeof(OVER)); (unsafe)
    memcpy_s(g_pOver, sizeof(OVER), pBuf, sizeof(OVER));

    // When the counter is divisible by 10, we increment it by 7
    // Numbers 10 and 7 are chosen arbitarily

    if(0 == ((g_pOver->uCounter) % 10))
    {
        g_fBufferEmpty = FALSE;
        TRACE((TC_VD, TT_ERROR, "VDOVER: ICADataArrival g_fBufferEmpty made false"));
        g_pDrvToSrv->uCounter = g_pOver->uCounter + 7;

		// We just made data available to send.  Tell WD to poll us now if this is HPC.
		// Note, we could have just sent the data immediately via the HPC SendData
		// function.

		if(g_fIsHpc)
		{
			WDSET_REQUESTPOLL reqPoll;				  // struct to send to WD when requesting a poll
			UINT16 uiSize = sizeof(WDSETINFORMATION); // size of WdSetInformation
			WDSETINFORMATION wdsi;

			// Tell WD to poll us now

			reqPoll.pWdData          = g_pWd;
			reqPoll.pUserData        = &g_ulUserData;
			wdsi.WdInformationClass  = WdRequestPoll;
			wdsi.pWdInformation      = &reqPoll;
			wdsi.WdInformationLength = sizeof(WDSET_REQUESTPOLL);
			VdCallWd(pVd, WDxSETINFORMATION, &wdsi, &uiSize);
		}
    }

    TRACE((TC_VD, TT_API3, "VDOVER: ICADataArrival uCounter %d ", g_pOver->uCounter));
   return;
}

/*******************************************************************************
 *
 *  DriverPoll
 *
 *  The Winstation driver calls DriverPoll
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *    pVdPoll (input)
 *       pointer to the structure DLLPOLL or DLL_HPC_POLL in the HPC case.
 *    puiSize (input)
 *       size of DLLPOOL or DLL_HPC_POLL structure.
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - OK so far.  We will be polled again.
 *    CLIENT_STATUS_NO_DATA - No more data to send.
 *    CLIENT_STATUS_ERROR_RETRY - Could not send the data to the WD's output queue - no space.
 *                                Hopefully, space will be available next time.
 *    Otherwise, a fatal error code is returned from lower level functions.
 *
 *    NOTE:  CLIENT_STATUS_NO_DATA signals the WD that it is OK to stop
 *           polling until another host to client packet comes through.
 *
 * REMARKS:
 *    If polling is enabled (pre-HPC client, or HPC client with polling enabled),
 *    this function is called regularly.  DriverPoll is always called at least once.
 *    Otherwise (HPC with polling disabled), DriverPoll is called only when requested
 *    via WDSET_REQUESTPOLL or SENDDATA_NOTIFY.
 *
 ******************************************************************************/

int DriverPoll(PVD pVd, PVOID pVdPoll, PUINT16 puiSize)
{
    int rc = CLIENT_STATUS_NO_DATA;
    PDLLPOLL pVdPollLegacy;             // legacy DLLPOLL structure pointer
    PDLL_HPC_POLL pVdPollHpc;           // DLL_HPC_POLL structure pointer
    static BOOL fFirstTimeDebug = TRUE; // Only print on first invocation

    if(fFirstTimeDebug)
    {
        TRACE((TC_VD, TT_API2, "VDOVER: DriverPoll entered"));
    }

    // Trace the poll information.

	if(g_fIsHpc)
    {
        pVdPollHpc = (PDLL_HPC_POLL)pVdPoll;
        if(fFirstTimeDebug)
        {
            TRACE((TC_VD, TT_API2, "VDOVER:DriverPoll. HPC Poll information: ulCurrentTime: %u, nFunction: %d, nSubFunction: %d, pUserData: %x.",
                            pVdPollHpc->ulCurrentTime, pVdPollHpc->nFunction, pVdPollHpc->nSubFunction, pVdPollHpc->pUserData));
        }
    }
    else
    {
        pVdPollLegacy = (PDLLPOLL)pVdPoll;
        if(fFirstTimeDebug)
        {
            TRACE((TC_VD, TT_API2, "VDOVER:DriverPoll. Legacy Poll information: ulCurrentTime: %u.", pVdPollLegacy->CurrentTime));
        }
    }
    fFirstTimeDebug = FALSE;                            // No more initial tracing

    // Check for something to write

    if(g_fBufferEmpty)
    {
        rc = CLIENT_STATUS_NO_DATA;
		return(rc);
    }

	// Data is available to write.  Send it.

    g_pDrvToSrv->uType = OVERFLOW_JUMP;
    g_pDrvToSrv->uLen = sizeof(DRVRESP);

    g_MemorySections[0].pSection = (LPBYTE)g_pDrvToSrv;        // The body of the data to be sent
    g_MemorySections[0].length = (USHORT)g_pDrvToSrv->uLen;    // Its length

	// Check for new HPC write API

	if(g_fIsHpc)
	{
		// HPC does not support scatter write.  If there are multiple buffers to write
		// to a single packet, you must consolidate the buffers into a single buffer to 
		// send the data to the engine.

		if(1 == NUMBER_OF_MEMORY_SECTIONS)
		{
			// Send an ICA packet.  Parameters:
			//    g_pWd - A pointer via the WDxSETINFORMATION engine call in DriverOpen().
			//    g_MemorySections[0].pSection - The address of the data to send.
			//    g_MemorySections[0].length - The size of the data to send.
			//    &g_ulUserData - An arbitrary pointer to user data.  This pointer will be returned with a
			//                  notification poll.  In this case, the pointer just points to arbitrary data
			//                  (0xCAACCAAC).
			//    SENDDATA_NOTIFY - Flags.  See vdapi.h:SENDDATA*.

			rc = g_pSendData((DWORD)g_pWd, g_usVirtualChannelNum, g_MemorySections[0].pSection, g_MemorySections[0].length, &g_ulUserData, SENDDATA_NOTIFY);
		}
		else
		{
			// Consolidate the buffers into a single buffer.

			LPBYTE pba = g_pbaConsolidationBuffer;              // target buffer
			INT nIndex;
			USHORT usTotalLength = 0;                           // total length to send
			USHORT usSizeOfBufferLeft = SIZEOF_CONSOLIDATION_BUFFER;  // available buffer left to fill

			for(nIndex = 0; nIndex < NUMBER_OF_MEMORY_SECTIONS; ++nIndex)
			{
				memcpy_s(pba, usSizeOfBufferLeft, g_MemorySections[nIndex].pSection, g_MemorySections[nIndex].length);
				pba += g_MemorySections[nIndex].length;           // bump target pointer for next memory section
				usSizeOfBufferLeft -= g_MemorySections[nIndex].length;  // reduce available buffer
				usTotalLength += g_MemorySections[nIndex].length; // accumulate total length sent
			}

			// Now send the single buffer.

			rc = g_pSendData((DWORD)g_pWd, g_usVirtualChannelNum, g_pbaConsolidationBuffer, usTotalLength, &g_ulUserData, SENDDATA_NOTIFY);
		}
	}
	else
	{
		// Use the legacy QueueVirtualWrite interface
		// Note that the FLUSH_IMMEDIATELY control will attempt to put the data onto the wire immediately,
		// causing any existing equal or higher priority data in the queue to be flushed as well.
		// This may result in the use of very small wire packets.  Using the value !FLUSH_IMMEDIATELY
		// may result in the data being delayed for a short while (up to 50 ms?) so it can possibly be combined
		// with other subsequent data to result in fewer and larger packets.
		
		rc = g_pQueueVirtualWrite(g_pWd, g_usVirtualChannelNum, g_MemorySections, NUMBER_OF_MEMORY_SECTIONS, FLUSH_IMMEDIATELY);
	}

    // Normal status returns are CLIENT_STATUS_SUCCESS (it worked) or CLIENT_ERROR_NO_OUTBUF (no room in output queue)

    if(CLIENT_STATUS_SUCCESS == rc)
    {
        TRACE((TC_VD, TT_API2, "VDOVER: g_fBufferEmpty made TRUE"));
        g_fBufferEmpty = TRUE;
    }
    else if(CLIENT_ERROR_NO_OUTBUF == rc)
    {
        // Try again later

        rc =  CLIENT_STATUS_ERROR_RETRY;
    }
    else if(CLIENT_STATUS_NO_DATA == rc)
    {
        // There was nothing to do.  Just fall through.
    }
    else
    {
		// If it is the HPC engine, we may be waiting on a callback.  This would
		// be indicated by a CLIENT_ERROR_BUFFER_STILL_BUSY return when we tried
		// to send data.  Just return CLIENT_STATUS_ERROR_RETRY in this case.

		if(g_fIsHpc && (rc == CLIENT_ERROR_BUFFER_STILL_BUSY))
		{
			rc =  CLIENT_STATUS_ERROR_RETRY;                        // Try again later
		}
    }
    return (rc);
}

/*******************************************************************************
 *
 *  DriverClose
 *
 *  The user interface calls VdClose to close a Vd before unloading it.
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to procotol driver data structure
 *    pVdClose (input/output)
 *       pointer to the structure DLLCLOSE
 *    puiSize (input)
 *       size of DLLCLOSE structure.
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - no error
 *
 ******************************************************************************/

int DriverClose(PVD pVd, PDLLCLOSE pVdClose, PUINT16 puiSize)
{
    TRACE((TC_VD, TT_API1, "VDOVER: DriverClose entered"));
    if(NULL != g_pDrvToSrv)
    {
        free(g_pDrvToSrv);
        g_pDrvToSrv = NULL;
    }
    if(NULL != g_pOver)
    {
        free(g_pOver);
        g_pOver = NULL;
    }
    return(CLIENT_STATUS_SUCCESS);
}

/*******************************************************************************
 *
 *  DriverInfo
 *
 *    This routine is called to get module information
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *    pVdInfo (output)
 *       pointer to the structure DLLINFO
 *    puiSize (output)
 *       size of DLLINFO structure
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - no error
 *
 ******************************************************************************/

int DriverInfo(PVD pVd, PDLLINFO pVdInfo, PUINT16 puiSize)
{
    USHORT ByteCount;
    PVDOVER_C2H pVdData;
    PMODULE_C2H pHeader;
    PVDFLOW pFlow;

    ByteCount = sizeof(VDOVER_C2H);

    *puiSize = sizeof(DLLINFO);

    TRACE((TC_VD, TT_API1, "VDOVER: DriverInfo entered"));

    // Check if buffer is big enough
    // If not, the caller is probably trying to determine the required
    // buffer size, so return it in ByteCount.

    if(pVdInfo->ByteCount < ByteCount)
    {
        pVdInfo->ByteCount = ByteCount;
        return(CLIENT_ERROR_BUFFER_TOO_SMALL);
    }

    // Initialize default data

    pVdInfo->ByteCount = ByteCount;
    pVdData = (PVDOVER_C2H) pVdInfo->pBuffer;

    // Initialize module header

    pHeader = &pVdData->Header.Header;
    pHeader->ByteCount = ByteCount;
    pHeader->ModuleClass = Module_VirtualDriver;

    pHeader->VersionL = CTXOVER_VER_LO;
    pHeader->VersionH = CTXOVER_VER_HI;

    //strcpy((char*)(pHeader->HostModuleName), "ICA"); /* max 8 characters */  // unsafe
    strcpy_s((char*)(pHeader->HostModuleName), sizeof(pHeader->HostModuleName), "ICA"); // max 8 characters

    // Initialize virtual driver header

    pFlow = &pVdData->Header.Flow;
    pFlow->BandwidthQuota = 0;
    pFlow->Flow = VirtualFlow_None;

    // Add our own data

    pVdData->usMaxDataSize = g_usMaxDataSize;

    return(CLIENT_STATUS_SUCCESS);
}

/*******************************************************************************
 *
 *  DriverQueryInformation
 *
 *   Required vd function.
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *    pVdQueryInformation (input/output)
 *       pointer to the structure VDQUERYINFORMATION
 *    puiSize (output)
 *       size of VDQUERYINFORMATION structure
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - no error
 *
 ******************************************************************************/

int DriverQueryInformation(PVD pVd, PVDQUERYINFORMATION pVdQueryInformation, PUINT16 puiSize)
{
    TRACE((TC_VD, TT_API1, "VDOVER: DriverQueryInformation entered"));
    TRACE((TC_VD, TT_API2, "pVdQueryInformation->VdInformationClass = %d", pVdQueryInformation->VdInformationClass));

    *puiSize = sizeof(VDQUERYINFORMATION);

    return(CLIENT_STATUS_SUCCESS);
}

/*******************************************************************************
 *
 *  DriverSetInformation
 *
 *   Required vd function.
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *    pVdSetInformation (input/output)
 *       pointer to the structure VDSETINFORMATION
 *    puiSize (input)
 *       size of VDSETINFORMATION structure
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - no error
 *
 ******************************************************************************/

int DriverSetInformation(PVD pVd, PVDSETINFORMATION pVdSetInformation, PUINT16 puiSize)
{
    TRACE((TC_VD, TT_API1, "VDOVER: DriverSetInformation entered"));
    TRACE((TC_VD, TT_API2, "pVdSetInformation->VdInformationClass = %d", pVdSetInformation->VdInformationClass));

   return(CLIENT_STATUS_SUCCESS);
}

/*******************************************************************************
 *
 *  DriverGetLastError
 *
 *   Queries error data.
 *   Required vd function.
 *
 * ENTRY:
 *    pVd (input)
 *       pointer to virtual driver data structure
 *    pLastError (output)
 *       pointer to the error structure to return (message is currently always
 *       NULL)
 *
 * EXIT:
 *    CLIENT_STATUS_SUCCESS - no error
 *
 ******************************************************************************/

int DriverGetLastError(PVD pVd, PVDLASTERROR pLastError)
{
    TRACE((TC_VD, TT_API1, "VDOVER: DriverGetLastError entered"));
    // Interpret last error and pass back code and string data

    pLastError->Error = pVd->LastError;
    pLastError->Message[0] = '\0';
    return(CLIENT_STATUS_SUCCESS);
}

