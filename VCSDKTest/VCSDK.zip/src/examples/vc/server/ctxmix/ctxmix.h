/**********************************************************************
*
* ctxmix.h
*
* The code and comments contained in this file are provided "as is"
* without warranty of any kind, either expressed or implied,
* including, but not limited to, the implied warranties of
* merchantability and/or fitness for a particular purpose.
* You have the right to use, modify, reproduce, and distribute
* this file, and/or any modified version of this file, in any way
* that you find useful, provided that you agree that Citrix Systems
* has no warranty obligations or liability for this or any other
* sample file.
*
* $Id: //RfWin/Release-Kiwi/CitrixReceiver/src/examples/vc/server/ctxmix/ctxmix.h#1 $
*
* Copyright (C) Citrix Systems, Inc.  All Rights Reserved.
*
**********************************************************************/

#ifndef _CTXMIX_H
#define _CTXMIX_H


/*
 * General application definitions.
 */
#define SUCCESS 0
#define FAILURE 1

#define MAX_IDS_LEN   256   // maximum length that the input parm can be

/*
 * Resource string IDs
 */
#define IDS_ERROR_MALLOC                                100
#define IDS_ERROR_OPEN_FAILED                           101
#define IDS_ERROR_WRITE_FAILED                          102
#define IDS_ERROR_READ_FAILED                           103
#define IDS_ERROR_WRITE_SHORT                           104
#define IDS_ERROR_READ_SHORT                            105
#define IDS_ERROR_CTXMIX_FAIL                           106
#define IDS_ERROR_NEEDS_SESSION                         107
#define IDS_ERROR_QUERY_SESSION_FAIL                    108
#define IDS_OPENED_CHANNEL                              109



/*
 *  Local function prototypes
 */

VOID WINAPI PrintMessage( int nResourceID, ...);

DWORD 
Srv_AddNo(LPBYTE pSend, LPBYTE pRecv,USHORT dwArg1, USHORT dwArg2);

BOOLEAN 
Srv_DispStr(LPBYTE pSend,PUCHAR pStr);

VOID 
Srv_Time(LPBYTE pSend, LPBYTE pRecv);

BOOLEAN
SendCommand (LPBYTE pSend,LPBYTE pRecv);

#endif /* _CTXMIX_H */
