Citrix Virtual Channel Software Development Kit (SDK) 18.0

Readme

    For the latest critical updates for Citrix products, see http://support.citrix.com/criticalupdates.
    For information about new features and system requirements, see the product administration guides.

Contents

    Finding Documentation
    Getting Support
    Introduction
    What's New in this Release
    Build Instructions

Finding Documentation
    Download the Zip file from https://www.citrix.co.in/downloads/citrix-receiver/virtual-channel-sdks/virtual-channel-sdk.html. Pick the latest version of the SDk in the Downloads page.
VCSDK Document can be found in \VCSDK\docs\vcsdk.pdf once you unzip the file.
    
    Online documentation is provided as Adobe Portable Document Format (PDF) files. To view, search, and print the PDF documentation, you need Adobe Reader (supported versions include 5.0.5 with Search, Version 6, 7, 8, 9 or 10).
    To provide feedback about the documentation, go to www.citrix.com and click Support > Knowledge Center > Product Documentation. To access the feedback form, click the Submit Documentation Feedback link. 

 
Getting Support

    Citrix provides technical support primarily through Citrix Solutions Advisor. Contact your supplier for first-line support or use Citrix Online Technical Support to find the nearest Citrix Solutions Advisor. Citrix offers online technical support services on the Citrix Support Web site. The Support page includes links to downloads, the Citrix Knowledge Center, Citrix Consulting Services, and other useful support pages. The Citrix Developer Center at http://support.citrix.com/developers is the home for all technical resources and discussions involving the use of Citrix Software Development Kits (SDKs). You can find access to SDKs, sample code and scripts, extensions and plug-ins, and SDK documentation. Also included are the Citrix Developer Network forums, where technical discussions take place around each of the Citrix SDKs.

Introduction

    A Citrix Independent Computing Architecture (ICA) virtual channel is a bidirectional error-free connection used for the exchange of generalized packet data between a server running Citrix Xenapp and a XenApp Client. You can create virtual channels to add functionality to the clients. Possible uses for virtual channels include support for administrative functions, new data streams, and new devices. The Citrix Virtual Channel Software Development Kit (VCSDK) allows you to write both server-side applications and client-side drivers to support additional virtual channels using the Citrix ICA protocol. The server-side virtual channel applications run on servers running Presentation Server. This SDK provides support for writing new virtual channels only for the Citrix Win32 client.

Important: Use Version 18.0 of the Citrix Virtual Channel SDK with Citrix Xenapp Clients Version 18.0 or later. The Citrix Virtual Channel SDK provides the following:

    Description of the architecture of the ICA protocol as it relates to virtual channels.
    Citrix Virtual Driver Application Programming Interface (VDAPI) that you use with the virtual channel functions to create new virtual channels. The virtual channel support provided by VDAPI makes writing your own virtual channels easier.
    Working source code for several example virtual channels that demonstrates programming techniques. 

For more information about this SDK, refer to the Citrix Virtual Channel Software Development Kit.

What's New in this Release
  The SDK's compiles using Visual Studio 2017. So you need VS17 installed on the system to compile the binaries.


Build Instructions
1.	Install Visual Studio 17

2.	Install the WFAPI SDK (Download it from https://www.citrix.co.in/community/citrix-developer/xenapp-xendesktop/wfapi-sdk.html).

3.	Download the VcSdk to a new C:\VcSdk directory (Download it from https://www.citrix.co.in/downloads/citrix-receiver/virtual-channel-sdks/virtual-channel-sdk.html).

4. 	At the command prompt, set an environment variable:
      	WFAPILIBPATH = C:\Program Files (x86)\Citrix\WfApiSDK 
	or 
      	WFAPILIBPATH = C:\Program Files\Citrix\WfApiSDK
    	depending on architecture. 

5.	Change to directory C:\VCSDK\src\examples\vc in the command window.
		A.	Run buildit.bat.

---------------------------------------------
