/******************************************************************************
*
*  WCECALLS.H
*
*  Support for ANSI versions of Win32 files.
*  Windows CE has no ANSI support so we will add
*  all needed APIs here.
*
*  Copyright 1998-2015 Citrix Systems, Inc.  
*
*******************************************************************************/

#pragma once

