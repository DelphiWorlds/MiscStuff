/*************************************************************************
*
* clib.h
*
* Header file for C runtime library routines
*
* Copyright 1998-2015 Citrix Systems, Inc. 
*
*************************************************************************/

#ifndef _CLIB_H_
#define _CLIB_H_

#pragma once

/*
 *  Include the platform specific clib file
 */

#include <platclib.h>

#endif /* _CLIB_H_ */
